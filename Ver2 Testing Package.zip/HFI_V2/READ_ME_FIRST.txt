HFI RETIREMENT JOURNEY - VERSION 2 TESTING PACKAGE
Internal testing with fictional information only
Build: 24 October 2026

START HERE
1. Save this ZIP and extract all its files. Do not run the app inside a ZIP preview.
2. Open HFI_V2_Complete_Testing_Guide.docx. Its first page is the page index.
3. Open START_HERE.html in desktop Chrome or Edge. No installation or ChatGPT login is needed.
4. Follow the guide in page order. It contains 73 numbered test scenarios, fictional inputs, expected results and a final coverage checklist.
5. Read HFI_V2_Planner_Feedback_and_Action_Taken.docx for the six planners' observations, comments and actions taken in V2.

KEEP THE SAMPLES FOLDER
- pension_sample.txt: sample labelled pension information.
- pension_corrected.txt: corrected version for the document-correction test.
- hfi_existing_facts.json: sample exchange of selected existing HFI facts; not a full app backup.

TEST RECORDS AND FEEDBACK
Each tester has a separate browser-local copy. Records are not shared between planners.
Use the same file location, browser and profile when reopening. Private browsing and office policy can restrict local saving.
Mark each test Pass, Fail, Blocked or Not run. Record issues in Testing feedback and export your findings.
Before resetting or moving the app, export test records and feedback separately. Record exports do not include attachment binaries. Keep your original fictional samples.
Use only invented client details. Do not upload real client records, passwords or family folders.

WHAT THIS DRAFT DOES NOT YET CONNECT
Secure individual logins and shared server records, PDF/scan AI reading, live HOPS/Vanguard feeds and automatic email/WhatsApp delivery remain production dependencies. The identity selector demonstrates workflow scope; it is not authentication.
The guide explains the testable functions and their limits. A passed draft test is not production approval.

IF OFFICE EMAIL BLOCKS THE ATTACHMENT
Ask IT to distribute the unchanged package through an approved internal folder. Do not bypass company or browser security controls.

FILES FOR THE COORDINATOR
Suggested_Email_to_Testers.txt contains optional covering text to copy into your own email. No email has been sent by the app or by preparing this package.
